fn bloxdTerrainSurface(s: BloxdSurfaceIn) -> BloxdSurface {
    var surfaceOut = bloxdDefaultSurface(s);

    let baseColor = s.colour;
    let luminance = dot(baseColor, vec3f(0.2126, 0.7152, 0.0722));
    let adjustedColor = mix(vec3f(luminance), baseColor, 1.24);
    let contrastColor = (adjustedColor - vec3f(0.43)) * 1.13 + vec3f(0.43);

    surfaceOut.colour = max(contrastColor, vec3f(0.0));

#ifdef BLOXD_ALPHA
    surfaceOut.alpha = s.alpha;
#endif

    return surfaceOut;
}

fn bloxdTerrainLight(s: BloxdSurface, l: BloxdLightIn) -> BloxdLight {
    var out = bloxdDefaultLight(s, l);
    
    let sky = clamp(l.skyLight, 0.0, 1.0);
    let blockInt = max(l.blockLight.r, max(l.blockLight.g, l.blockLight.b));
    let keep = 0.12 + 0.88 * blockInt;          // lift lamp-lit spots
    let caveDarkening = mix(keep, 1.0, sky * sky); // nonlinear cave/night darkening

    let n = normalize(l.normal);
    let sunLen = length(bloxdSunDirection());

    if (sunLen > 0.5) {
        let sunDir = bloxdSunDirection() / sunLen;
        let lambert = max(dot(n, sunDir), 0.0);
        
        // Steepened shadow curve for deeper contrast
        let shadowFactor = smoothstep(0.0, 0.85, lambert);
        let deepenedShadow = pow(shadowFactor, 1.2);

        let horizonTint = vec3f(0.6, 0.7, 0.9);
        let sunLightTint = vec3f(1.15, 1.055, 0.88);
        let directionalLight = mix(horizonTint, sunLightTint, deepenedShadow);

        // Lowered ambient minimum so unlit faces get significantly darker
        let ambientLightFactor = 0.5 + lambert * 0.6;
        let verticalAlign = smoothstep(0.20, 0.95, n.y);
        let upwardBoost = 1.0 + verticalAlign * 0.055;
        let sunGlow = pow(shadowFactor, 4.0) * 0.025;

        out.colour *= directionalLight * ambientLightFactor * upwardBoost * caveDarkening;
        out.colour += vec3f(sunGlow, sunGlow * 0.66, sunGlow * 0.30) * sky;
    } else {
        out.colour *= caveDarkening;
    }

    return out;
}