fn bloxdTerrainSurface(surface: BloxdSurfaceIn) -> BloxdSurface {
    var result: BloxdSurface = bloxdDefaultSurface(surface);
    result.colour = surface.colour;
    result.emission = vec3f(0.0);
#ifdef BLOXD_ALPHA
    result.alpha = surface.alpha;
#endif
    return result;
}

fn bloxdTerrainLight(surface: BloxdSurface, light: BloxdLightIn) -> BloxdLight {
    var result: BloxdLight = bloxdDefaultLight(surface, light);
    result.colour = surface.colour;
    return result;
}