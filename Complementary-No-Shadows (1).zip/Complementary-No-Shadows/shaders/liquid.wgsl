fn waterProjectedUv(worldPosition: vec3f, normal: vec3f) -> vec2f {
    let face = abs(normal);
    if (face.y >= face.x && face.y >= face.z) {
        return worldPosition.xz;
    }
    if (face.x >= face.z) {
        return vec2f(worldPosition.z, worldPosition.y);
    }
    return vec2f(worldPosition.x, worldPosition.y);
}

fn waterCellRandom(cell: vec2f) -> f32 {
    return fract(sin(dot(cell, vec2f(127.1, 311.7))) * 43758.5453) * 2.0 - 1.0;
}

fn waterBlockVariation(uv: vec2f) -> vec3f {
    let cell = floor(uv);
    let local = fract(uv);
    let blend = local * local * (vec2f(3.0) - 2.0 * local);
    let bottomLeft = waterCellRandom(cell);
    let bottomRight = waterCellRandom(cell + vec2f(1.0, 0.0));
    let topLeft = waterCellRandom(cell + vec2f(0.0, 1.0));
    let topRight = waterCellRandom(cell + vec2f(1.0, 1.0));
    let bottom = mix(bottomLeft, bottomRight, blend.x);
    let top = mix(topLeft, topRight, blend.x);
    let value = mix(bottom, top, blend.y);
    let slopeX = mix(bottomRight - bottomLeft, topRight - topLeft, blend.y) * 6.0 * local.x * (1.0 - local.x);
    let slopeY = (top - bottom) * 6.0 * local.y * (1.0 - local.y);
    return vec3f(value, slopeX, slopeY);
}

fn waterWave(uv: vec2f, time: f32) -> f32 {
    let longWave = sin(dot(uv, vec2f(0.62, 0.78)) * 1.55 + time * 1.05);
    let crossWave = sin(dot(uv, vec2f(-0.8, 0.6)) * 2.1 - time * 0.72);
    let fineRipple = sin(uv.x * 4.1 + sin(uv.y * 2.7 + time * 0.8) + time * 1.4);
    let blockVariation = waterBlockVariation(uv).x;
    return longWave * 0.58 + crossWave * 0.28 + fineRipple * 0.14 + blockVariation * 0.2;
}

fn waterWaveGradient(uv: vec2f, time: f32) -> vec2f {
    let longPhase = dot(uv, vec2f(0.62, 0.78)) * 1.55 + time * 1.05;
    let crossPhase = dot(uv, vec2f(-0.8, 0.6)) * 2.1 - time * 0.72;
    let fineInner = uv.y * 2.7 + time * 0.8;
    let finePhase = uv.x * 4.1 + sin(fineInner) + time * 1.4;
    let blockVariation = waterBlockVariation(uv);
    let longSlope = cos(longPhase) * 0.58 * 1.55;
    let crossSlope = cos(crossPhase) * 0.28 * 2.1;
    let fineSlope = cos(finePhase) * 0.14;
    return vec2f(
        longSlope * 0.62 - crossSlope * 0.8 + fineSlope * 4.1 + blockVariation.y * 0.2,
        longSlope * 0.78 + crossSlope * 0.6 + fineSlope * cos(fineInner) * 2.7 + blockVariation.z * 0.2
    );
}

fn waterPerturbedNormal(uv: vec2f, time: f32, waveBoost: f32) -> vec3f {
    let slope = waterWaveGradient(uv, time) * (0.055 + waveBoost * 0.14);
    return normalize(vec3f(-slope.x, 1.0, -slope.y));
}

fn waterFresnel(normal: vec3f, viewDirection: vec3f) -> f32 {
    let viewCosine = clamp(abs(dot(normal, viewDirection)), 0.0, 1.0);
    return 0.02 + 0.98 * pow(1.0 - viewCosine, 5.0);
}

#ifndef BLOXD_STRICT
fn bloxdLiquidVertex(vertex: BloxdVertexIn) -> BloxdVertex {
    var result: BloxdVertex = bloxdDefaultVertex(vertex);
    let worldPosition = bloxdWorldPosition(vertex.position);
    let uv = waterProjectedUv(worldPosition, normalize(vertex.normal));
    result.position.y += waterWave(uv, bloxdTime()) * 0.055;
    return result;
}
#endif

fn bloxdLiquidSurface(surface: BloxdSurfaceIn) -> BloxdSurface {
    var result: BloxdSurface = bloxdDefaultSurface(surface);
    let worldPosition = bloxdWorldPosition(surface.position);
    let uv = waterProjectedUv(worldPosition, normalize(surface.normal));
    let geometricNormal = normalize(surface.normal);
    let viewDirection = normalize(bloxdEyePosition() - surface.position);
    let viewDistance = length(bloxdEyePosition() - surface.position);
    let grazingAngle = 1.0 - abs(dot(geometricNormal, viewDirection));
    let nearBoost = 1.0 - smoothstep(4.0, 16.0, viewDistance);
    let waveBoost = max(nearBoost, smoothstep(0.25, 0.78, grazingAngle));
    let normal = waterPerturbedNormal(uv, bloxdTime(), waveBoost);
    let fresnel = waterFresnel(normal, viewDirection);
    let baseLuminance = dot(surface.colour, vec3f(0.2126, 0.7152, 0.0722));
    let neutralizedColour = mix(surface.colour, vec3f(baseLuminance), 0.2);
    let reflectionTint = vec3f(0.64, 0.83, 0.74);

    result.colour = neutralizedColour * vec3f(0.94, 1.1, 0.96);
    result.colour = mix(result.colour, reflectionTint, fresnel * 0.34);
    result.emission = vec3f(0.0);
#ifdef BLOXD_ALPHA
    result.alpha = surface.alpha * 0.7;
#endif
    return result;
}

fn bloxdLiquidLight(surface: BloxdSurface, light: BloxdLightIn) -> BloxdLight {
    var result: BloxdLight = bloxdDefaultLight(surface, light);
    let worldPosition = bloxdWorldPosition(light.position);
    let uv = waterProjectedUv(worldPosition, normalize(light.normal));
    let geometricNormal = normalize(light.normal);
    let viewDirection = normalize(bloxdEyePosition() - light.position);
    let viewDistance = length(bloxdEyePosition() - light.position);
    let grazingAngle = 1.0 - abs(dot(geometricNormal, viewDirection));
    let nearBoost = 1.0 - smoothstep(4.0, 16.0, viewDistance);
    let waveBoost = max(nearBoost, smoothstep(0.25, 0.78, grazingAngle));
    let waveNormal = waterPerturbedNormal(uv, bloxdTime(), waveBoost);
    let normal = normalize(mix(geometricNormal, waveNormal, clamp(abs(geometricNormal.y), 0.0, 1.0)));
    let fresnel = waterFresnel(normal, viewDirection);
    let sunDirectionRaw = bloxdSunDirection();
    let sunStrength = clamp(length(sunDirectionRaw), 0.0, 1.0);
    let sunDirection = sunDirectionRaw / max(sunStrength, 0.0001);
    let halfDirection = normalize(viewDirection + sunDirection);
    let highlightAlignment = max(dot(normal, halfDirection), 0.0);
    let broadGlint = pow(highlightAlignment, mix(48.0, 24.0, waveBoost)) * sunStrength * (1.0 + waveBoost * 2.2);
    let sharpGlint = pow(highlightAlignment, mix(180.0, 100.0, waveBoost)) * sunStrength * (1.0 + waveBoost * 1.5);
    let fogLuminance = dot(light.fogColour, vec3f(0.2126, 0.7152, 0.0722));
    let reflectedSky = mix(vec3f(fogLuminance), light.fogColour, 0.2);

    result.colour = surface.colour;
    result.colour = mix(result.colour, reflectedSky, fresnel * 0.32);
    result.colour += vec3f(0.92, 0.96, 0.94) * broadGlint * 0.16;
    result.colour += vec3f(1.0, 0.98, 0.9) * sharpGlint * 0.55;
    return result;
}