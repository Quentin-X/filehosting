fn bloxd_terrain_surface(s: bloxd_SurfaceIn) -> bloxd_Surface {
	var result: bloxd_Surface = bloxd_defaultSurface(s);
	let normal = normalize(s.normal);
	let sunStrength = clamp(length(s.sunDirection), 0.0, 1.0);
	let sunFacing = max(dot(normal, s.sunDirection), 0.0);
	let warmLight = vec3f(1.2, 1.1, 0.86);
	let coolShade = vec3f(0.9, 0.96, 1.12);
	let shadeBalance = mix(vec3f(1.0), coolShade, (1.0 - sunStrength) * 0.55);
	let directionalTint = mix(shadeBalance, warmLight, sunFacing * 0.85);
	let skyFill = 1.0 + max(normal.y, 0.0) * 0.06;

	result.colour = s.colour * directionalTint * skyFill;
	result.emission = vec3f(0.0);
#ifdef BLOXD_ALPHA
	result.alpha = s.alpha;
#endif
	return result;
}

fn bloxd_terrain_light(surface: bloxd_Surface, light: bloxd_LightIn) -> bloxd_Light {
	var result: bloxd_Light = bloxd_defaultLight(surface, light);
	let sunlit = smoothstep(0.08, 0.72, light.directional);
	let coolShade = vec3f(0.78, 0.86, 1.1);
	let warmSun = vec3f(1.24, 1.13, 0.9);
	result.colour = result.colour * mix(coolShade, warmSun, sunlit);
	return result;
}
