fn bloxd_liquid_surface(s: bloxd_SurfaceIn) -> bloxd_Surface {
	var result: bloxd_Surface = bloxd_defaultSurface(s);
	let normal = normalize(s.normal);
	let sunFacing = max(dot(normal, s.sunDirection), 0.0);
	let coolWater = vec3f(0.62, 0.96, 1.28);
	let sunGlintTint = vec3f(1.22, 1.12, 0.92);
	let waterTint = mix(coolWater, sunGlintTint, sunFacing * 0.5);

	result.colour = s.colour * waterTint;
	result.emission = vec3f(0.0);
#ifdef BLOXD_ALPHA
	result.alpha = s.alpha;
#endif
	return result;
}

fn bloxd_liquid_light(surface: bloxd_Surface, light: bloxd_LightIn) -> bloxd_Light {
	var result: bloxd_Light = bloxd_defaultLight(surface, light);
	let sunlit = smoothstep(0.08, 0.72, light.directional);
	let coolShade = vec3f(0.82, 0.96, 1.14);
	let warmSun = vec3f(1.2, 1.12, 0.94);
	result.colour = result.colour * mix(coolShade, warmSun, sunlit);
	return result;
}
