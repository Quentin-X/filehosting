fn bloxdLiquidSurface(s: BloxdSurfaceIn) -> BloxdSurface {
    var out = bloxdDefaultSurface(s);
    
    // Use local position to stay safe from anti-cheat and xray restrictions
    let posX = s.position.x;
    let posZ = s.position.z;
    
    let time = bloxdSeconds() % 3600.0;
    
    // Multi-directional waves mapped to local coordinates
    let wave1 = sin(time * 2.0 + posX * 1.2 + posZ * 0.5);
    let wave2 = sin(time * 2.3 - posX * 0.5 + posZ * 1.2);
    let wave3 = sin(time * 1.8 + posX * 1.0 - posZ * 1.0);
    
    let ripple = (wave1 + wave2 + wave3) / 3.0;

    // Natural lake and river blue-green tint with higher contrast factor to stay visible under light
    let lakeColour = vec3f(0.12, 0.35, 0.05);
    let rippleFactor = 1.0 + ripple * 0.35; // Increased contrast so light doesn't wash it out
    
    out.colour = clamp(out.colour * lakeColour * rippleFactor, vec3f(0.0), vec3f(1.0));

    #ifdef BLOXD_ALPHA
    out.alpha = 0.6;
    #endif
    return out;
}