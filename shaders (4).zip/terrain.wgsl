// Shader pack API v5 (pack.json must say "apiVersion": 5, as a number)

const SHADOW_STRENGTH: f32 = 0.75;

// Shadow look.
// SOFT_BLOCKS: how many blocks deep into the occluded area a shadow takes to reach full darkness
//   (0.0 = hard edge as before; thick canopies get dark cores, thin edges stay light).
// TINT: what full shadow multiplies the colour by, per channel. Bluish, because shadows are lit by the sky.
// AMBIENT_PART: share of SHADOW_STRENGTH that darkens ALL light by day (sky occlusion). At night it is 1.0.
// SUN_PART: how strongly shadow removes the sun's light only (faces turned away from the sun have none to lose).
// DUSK_FADE: share of the sun shadow removed when the sun is on the horizon (0.0 = no fade, 1.0 = all).
const SHADOW_SOFT_BLOCKS: f32 = 1.5;
const SHADOW_TINT: vec3f = vec3f(0.12, 0.20, 0.38);
const SHADOW_AMBIENT_PART: f32 = 0.4;
const SHADOW_SUN_PART: f32 = 0.7;
const SHADOW_DUSK_FADE: f32 = 0.6;

// PROTOTYPE: sun-direction shadow skew. The shadow edge on the side facing the sun retreats by up to
// this many blocks per unit of shadow length (cot of sun elevation), so shadows look pushed away from
// the sun. 0.0 = off (plain overhead shadows). Noisy and approximate: see the notes in the shader.
const SHADOW_SKEW_BLOCKS: f32 = 2.0;
const BLOCK_VARIATION: f32 = 0.04;
const CELL_VARIATION: f32 = 0.06;
const CELL_FAR: f32 = 40.0;
const CELLS_PER_BLOCK: i32 = 8;

// bloxdTimeWrap was removed in v3; wrap seconds ourselves so animation stays precise.
const TIME_WRAP: f32 = 3600.0;

const WIND_STRENGTH: f32 = 1.0;
const WIND_SPEED: f32 = 0.8;
const LEAF_SHIMMER: f32 = 0.3;   // also used for wool (see isWool)
const GRASS_GUSTS: f32 = 0.16;
const GUST_DIRECTION: vec2f = vec2f(0.92, 0.39);

// Anti-mist controls. Raise for punchier colours/textures, set to 0.0 / 1.0 to disable.
const CLARITY_SATURATION: f32 = 0.38;
const CLARITY_CONTRAST: f32 = 1.12;

// Contact shadow strength on vertical (side) faces relative to top/bottom faces.
// 1.0 = same as ground, 0.0 = no contact shadow on sides.
const SIDE_SHADOW_SCALE: f32 = 0.5;

// Sunrise/sunset look. TINT multiplies the whole sunlit scene near the horizon;
// STRENGTH 0.0 = off, 1.0 = full tint. Make the tint redder by lowering G/B.
const SUNSET_TINT: vec3f = vec3f(1.30, 0.70, 0.48);
const SUNSET_STRENGTH: f32 = 0.75;

// Shiny blocks (see sunGlintAmount): emissive blocks, liquids and the textures listed there always
// count as shiny. These set how much of the sun highlights the other groups get (0.0 = none, 1.0 = full).
const SUN_GLINT_ROCK: f32 = 0.0;          // stone, andesite, diorite, granite, ores, sandstone...
const SUN_GLINT_OTHER_BLOCKS: f32 = 0.0;  // everything else

// Medium sun highlight, shiny blocks only: as wide as the broad sun glow, but subtle. It peaks at
// about strength x 1.2 (the broad glow peaks at about 0.46, the small sharp highlight at about 2.6).
const SHINY_SUN_STRENGTH: f32 = 0.1;
// Sun direction for ALL lighting-off lighting (shading and shiny highlights): about 10 am, roughly
// 40 degrees up and slanted from one side, instead of high noon. Normalised where used.
const FALLBACK_SUN: vec3f = vec3f(0, 0.65, 0);

// Lighting-off shading: brightness of faces away from the sun, brightness of fully sun-lit faces, and
// how far the light wraps past 90 degrees from the sun (higher = more faces lit, softer shading).
const FALLBACK_AWAY_LIGHT: f32 = 0.58;
const FALLBACK_LIT_LIGHT: f32 = 0.75;
const FALLBACK_LIGHT_WRAP: f32 = 0.5;

// Same idea for the real sun when lighting is on. WRAP: how far the sun's light wraps past 90 degrees
// (0.0 = the old hard edge, higher = more faces lit). AWAY_AMBIENT: brightness floor of faces turned
// away from the sun (0.60 = the old value, higher = less dark). 0.0 and 0.60 restore the old look.
const DAY_LIGHT_WRAP: f32 = 0.5;
const DAY_AWAY_AMBIENT: f32 = 0.72;

// Overall brightness of the lighting-off fallback (it is always "noon", so it reads brighter than a
// real day). 1.0 = as bright as a lit noon, lower = dimmer.
const NOON_FALLBACK_BRIGHTNESS: f32 = 0.8;

fn helperClamp(x: f32) -> f32 {
    return clamp(x, 0.0, 1.0);
}

fn helperSkyTransform(e: f32) -> f32 {
    let c = 1.0 - pow(max(1.0 - helperClamp(e), 0.0), 1.0 / 3.0);
    return 45.0 * c / max(1.0 + 2.0 * c, 1.0);
}

// v: sky light restored to about 0..15 levels, fw: fwidth(v) (taken by the caller, in uniform control flow).
// shrink: moves the shadow threshold down (in sky light levels, about 1 block each), so the shadow
// only starts that far inside the edge of the occluded area.
fn calculateContactShadow(v: f32, fw: f32, shrink: f32) -> f32 {
    let e = min(fw * 0.55, 0.40);
    // Wide ramp: the shadow builds up over SHADOW_SOFT_BLOCKS blocks instead of switching on at once.
    return smoothstep(14.12 - SHADOW_SOFT_BLOCKS - shrink - e, 14.93 - shrink + e, v);
}

fn pack_saturation(c: vec3f, amount: f32) -> vec3f {
    let luma = dot(c, vec3f(0.299, 0.587, 0.114));
    return clamp(mix(vec3f(luma), c, 1.0 + amount), vec3f(0.0), vec3f(1.0));
}

fn cellHash(p: vec3i) -> u32 {
    var h = (u32(p.x) * 0x73856bc3u) ^ (u32(p.y) * 0x476fab41u) ^ (u32(p.z) * 0x1aef67d7u);
    h = (h ^ (h >> 16u)) * 0x85ebca6bu;
    h ^= h >> 13u;
    return h;
}

fn hashUnit(h: u32) -> f32 {
    return f32(h & 0xffffffu) / 16777216.0;
}

fn mistCell(i: vec2i, layer: u32) -> f32 {
    var h = (bitcast<u32>(i.x) * 0x27d4eb2du) ^ (bitcast<u32>(i.y) * 0x165667b1u) ^ (layer * 0x9e3779b9u);
    h = (h ^ (h >> 15u)) * 0x2c1b3c6du;
    h ^= h >> 13u;
    return f32(h >> 8u) / 16777216.0;
}

fn mistNoise(p: vec2f, layer: u32) -> f32 {
    let i = vec2i(floor(p));
    let f = fract(p);
    let u = f * f * (3.0 - 2.0 * f);
    let a = mix(mistCell(i, layer), mistCell(i + vec2i(1, 0), layer), u.x);
    let b = mix(mistCell(i + vec2i(0, 1), layer), mistCell(i + vec2i(1, 1), layer), u.x);
    return mix(a, b, u.y);
}

// Leaves are vegetation but not dirt (grass blocks are vegetation AND dirt). Flat plants (tall grass,
// flowers, crops) are vegetation too in API v5, but they are excluded so only real leaves shimmer.
fn isLeaf(flags: BloxdFlags) -> bool {
    return flags.vegetation && !flags.dirt && !flags.flat;
}

fn isGrassBlock(flags: BloxdFlags) -> bool {
    return flags.vegetation && flags.dirt;
}

// Wool, all 16 colours (texture names from the API texture catalogue; note "light_grey" spelling).
fn isWool(textureId: u32) -> bool {
    switch textureId {
        case bloxdTextureIdWoolColoredWhite, bloxdTextureIdWoolColoredOrange,
             bloxdTextureIdWoolColoredMagenta, bloxdTextureIdWoolColoredLightBlue,
             bloxdTextureIdWoolColoredYellow, bloxdTextureIdWoolColoredLime,
             bloxdTextureIdWoolColoredPink, bloxdTextureIdWoolColoredGray,
             bloxdTextureIdWoolColoredLightGrey, bloxdTextureIdWoolColoredCyan,
             bloxdTextureIdWoolColoredPurple, bloxdTextureIdWoolColoredBlue,
             bloxdTextureIdWoolColoredBrown, bloxdTextureIdWoolColoredGreen,
             bloxdTextureIdWoolColoredRed, bloxdTextureIdWoolColoredBlack: {
            return true;
        }
        default: {
            return false;
        }
    }
}

// How shiny a face is (0..1): scales both the small sharp sun highlight and the medium one.
// Texture names are the file names in CamelCase (API texture catalogue). A name that doesn't
// exist fails validation and turns the whole pack off, so only add names from that catalogue.
fn sunGlintAmount(flags: BloxdFlags, textureId: u32) -> f32 {
#ifdef BLOXD_SCENE_DEPTH
    // BLOXD_SCENE_DEPTH is defined exactly in the liquid variants, so this branch is water/lava.
    return 1.0;
#else
    // Neon, lamps, lava, glowing ores...
    if (flags.emissive) { return 1.0; }

    switch textureId {
        // Glass
        case bloxdTextureIdGlass, bloxdTextureIdGlassBlack, bloxdTextureIdGlassBlue, bloxdTextureIdGlassBrown,
             bloxdTextureIdGlassCyan, bloxdTextureIdGlassGray, bloxdTextureIdGlassGreen,
             bloxdTextureIdGlassLightBlue, bloxdTextureIdGlassLightGray, bloxdTextureIdGlassLime,
             bloxdTextureIdGlassMagenta, bloxdTextureIdGlassOrange, bloxdTextureIdGlassPink,
             bloxdTextureIdGlassPurple, bloxdTextureIdGlassRed, bloxdTextureIdGlassSilver,
             bloxdTextureIdGlassWhite, bloxdTextureIdGlassYellow: {
            return 1.0;
        }
        // Patterned glass
        case bloxdTextureIdPatternedGlassBlack, bloxdTextureIdPatternedGlassBlue,
             bloxdTextureIdPatternedGlassBrown, bloxdTextureIdPatternedGlassCyan,
             bloxdTextureIdPatternedGlassGray, bloxdTextureIdPatternedGlassGreen,
             bloxdTextureIdPatternedGlassLightBlue, bloxdTextureIdPatternedGlassLightGray,
             bloxdTextureIdPatternedGlassLime, bloxdTextureIdPatternedGlassMagenta,
             bloxdTextureIdPatternedGlassOrange, bloxdTextureIdPatternedGlassPink,
             bloxdTextureIdPatternedGlassPurple, bloxdTextureIdPatternedGlassRed,
             bloxdTextureIdPatternedGlassWhite, bloxdTextureIdPatternedGlassYellow: {
            return 1.0;
        }
        // Ice and ice bricks (+ slab)
        case bloxdTextureIdIce, bloxdTextureIdIceBrick, bloxdTextureIdSlabIceBrickSide: {
            return 1.0;
        }
        // Blocks of iron, gold, lapis, emerald, diamond, moonstone (no coal)
        case bloxdTextureIdIronBlock, bloxdTextureIdGoldBlock, bloxdTextureIdLapisBlock,
             bloxdTextureIdEmeraldBlock, bloxdTextureIdDiamondBlock, bloxdTextureIdMoonstoneBlock: {
            return 1.0;
        }
        // Metal and gem ores (no coal), including the pure variants
        case bloxdTextureIdIronOre, bloxdTextureIdGoldOre, bloxdTextureIdLapisOre,
             bloxdTextureIdEmeraldOre, bloxdTextureIdDiamondOre, bloxdTextureIdMoonstoneOre,
             bloxdTextureIdCopperOre, bloxdTextureIdPureIronOre, bloxdTextureIdPureGoldOre,
             bloxdTextureIdPureDiamondOre, bloxdTextureIdPureMoonstoneOre, bloxdTextureIdPureCopperOre: {
            return 1.0;
        }
        // Quartz, chiseled quartz, obsidian
        case bloxdTextureIdQuartzBlockSide, bloxdTextureIdQuartzBlockChiseled, bloxdTextureIdObsidian: {
            return 1.0;
        }
        // Ceramics (glazed terracotta), all colours
        case bloxdTextureIdWhiteGlazedTerracotta, bloxdTextureIdOrangeGlazedTerracotta,
             bloxdTextureIdMagentaGlazedTerracotta, bloxdTextureIdLightBlueGlazedTerracotta,
             bloxdTextureIdYellowGlazedTerracotta, bloxdTextureIdLimeGlazedTerracotta,
             bloxdTextureIdPinkGlazedTerracotta, bloxdTextureIdGrayGlazedTerracotta,
             bloxdTextureIdLightGrayGlazedTerracotta, bloxdTextureIdCyanGlazedTerracotta,
             bloxdTextureIdPurpleGlazedTerracotta, bloxdTextureIdBlueGlazedTerracotta,
             bloxdTextureIdBrownGlazedTerracotta, bloxdTextureIdGreenGlazedTerracotta,
             bloxdTextureIdRedGlazedTerracotta, bloxdTextureIdBlackGlazedTerracotta: {
            return 1.0;
        }
        // Smooth stone, diorite, andesite, granite (+ slabs)
        case bloxdTextureIdSmoothStone, bloxdTextureIdStoneDioriteSmooth, bloxdTextureIdStoneAndesiteSmooth,
             bloxdTextureIdStoneGraniteSmooth, bloxdTextureIdSlabSmoothStoneSide,
             bloxdTextureIdSlabStoneDioriteSmoothSide, bloxdTextureIdSlabStoneAndesiteSmoothSide,
             bloxdTextureIdSlabStoneGraniteSmoothSide: {
            return 1.0;
        }
        // Engraved stone, diorite, andesite, granite (+ slabs)
        case bloxdTextureIdStonebrickCarved, bloxdTextureIdEngravedDiorite, bloxdTextureIdEngravedAndesite,
             bloxdTextureIdEngravedGranite, bloxdTextureIdSlabStonebrickCarvedSide,
             bloxdTextureIdSlabEngravedDioriteSide, bloxdTextureIdSlabEngravedAndesiteSide,
             bloxdTextureIdSlabEngravedGraniteSide: {
            return 1.0;
        }
        // Iron watermelon
        case bloxdTextureIdIronWatermelonSide, bloxdTextureIdIronWatermelonTop: {
            return 1.0;
        }
        // Moonstone chest and iron chest (all faces; rotations share these textures)
        case bloxdTextureIdMoonstoneChestBack, bloxdTextureIdMoonstoneChestFront,
             bloxdTextureIdMoonstoneChestSide, bloxdTextureIdMoonstoneChestTop,
             bloxdTextureIdIronChestBack, bloxdTextureIdIronChestFront,
             bloxdTextureIdIronChestSide, bloxdTextureIdIronChestTop: {
            return 1.0;
        }
        default: {
        }
    }

    if (flags.rock) { return SUN_GLINT_ROCK; }
    return SUN_GLINT_OTHER_BLOCKS;
#endif
}

fn grassGust(place: vec3f, t: f32) -> f32 {
    let along = dot(place.xz, GUST_DIRECTION);
    let across = dot(place.xz, vec2f(-GUST_DIRECTION.y, GUST_DIRECTION.x));
    let wave = mistNoise(vec2f(along * 0.22 - t * 1.4, across * 0.07), 10u);
    let gusting = 0.55 + 0.45 * sin(t * 0.23 + along * 0.01);
    return smoothstep(0.55, 0.85, wave) * gusting;
}

// Shared final grade: clarity + distance haze (used by both lit and unlit paths)
fn finishLook(c: vec3f, l: BloxdLightIn) -> vec3f {
    var col = c;

    // Clarity: restore saturation and texture contrast (no clamp, to keep highlights)
    let clarityLuma = dot(col, vec3f(0.2126, 0.7152, 0.0722));
    col = max(mix(vec3f(clarityLuma), col, 1.0 + CLARITY_SATURATION), vec3f(0.0));
    col = max((col - vec3f(0.3)) * CLARITY_CONTRAST + vec3f(0.3), vec3f(0.0));

    let dist = distance(bloxdEyePosition(), l.position);
    let aerial = 1.0 - exp(-dist * 0.0035);
    let luma = dot(col, vec3f(0.2126, 0.7152, 0.0722));
    let hazy = mix(vec3f(luma), col, 0.5);
    col = mix(col, hazy, aerial * 0.16);

    // The game's fog colour is black (0) when the game has no fog: skip the haze then,
    // otherwise it would darken the distance towards black.
    let fogOn = max(l.fogColour.r, max(l.fogColour.g, l.fogColour.b)) > 0.001;
    let haze = clamp((dist - 40.0) / 128.0, 0.0, 1.0) * 0.35 * select(0.0, 1.0, fogOn);
    return mix(col, l.fogColour, haze);
}

// Fallback when lighting is off: the same shading as the day branch with a fixed mid-morning sun
// (FALLBACK_SUN) and full sky light. Shiny blocks (glintAmount) also get the medium highlight and
// the small sharp highlight (tinyCore), both from that same sun.
fn noonShade(c: vec3f, normal: vec3f, toEye: vec3f, glintAmount: f32) -> vec3f {
    let n = normalize(normal);
    let viewDir = normalize(toEye);
    let sunDir = normalize(FALLBACK_SUN);

    // Wrapped diffuse: faces up to FALLBACK_LIGHT_WRAP past 90 degrees from the sun still get some
    // light, so the top and both sun-side faces of a block are lit and the far faces aren't left dark.
    let lambert = max(dot(n, sunDir), 0.0);
    let wrapped = clamp((dot(n, sunDir) + FALLBACK_LIGHT_WRAP) / (1.0 + FALLBACK_LIGHT_WRAP), 0.0, 1.0);
    let litAmount = smoothstep(0.0, 0.85, wrapped);

    let shade = mix(FALLBACK_AWAY_LIGHT, FALLBACK_LIT_LIGHT, litAmount)
        * (1.0 + smoothstep(0.20, 0.95, n.y) * 0.05);
    // Cool tint away from the sun, warm tint in the sun
    let tint = mix(vec3f(0.94, 0.97, 1.04), vec3f(1.0, 0.99, 0.96), litAmount);

    var col = c * shade * tint;
    col += vec3f(pow(litAmount, 4.0) * 0.03);

    // Broad soft sun glow (kept: it also stops colours from over-saturating)
    let h = normalize(viewDir + sunDir);
    let ndh = max(dot(n, h), 0.0);
    col += pow(ndh, 0.01) * 0.4 * lambert * vec3f(1.15, 1.15, 1.15);

    // Medium highlight for shiny blocks (same sun)
    col += pow(ndh, 0.01) * SHINY_SUN_STRENGTH * lambert * glintAmount * vec3f(1.2, 1.2, 1.2);
    // Small sharp highlight for shiny blocks (same strength as in the lit day branch)
    col += pow(ndh, 800.0) * 2.0 * lambert * glintAmount * vec3f(1.3, 1.3, 1.3);
    return col * NOON_FALLBACK_BRIGHTNESS;
}

fn bloxdTerrainSurface(surface: BloxdSurfaceIn) -> BloxdSurface {
    var out = bloxdDefaultSurface(surface);
    out.colour = surface.colour;
#ifdef BLOXD_ALPHA
    out.alpha = surface.alpha;
#endif
    return out;
}

// All of this pack's lighting. Terrain, liquid and (non-entity) model light hooks call it, because in
// API v5 a deleted hook falls back to the engine default, not to the terrain hook.
fn shadeLight(s: BloxdSurface, l: BloxdLightIn) -> BloxdLight {
    var out = bloxdDefaultLight(s, l);

    // Derivatives (and fwidth) must be taken here, outside any branch (uniform control flow).
    // skyLevel is the engine's lifted sky light restored to about 0..15 levels (1 level per block).
    let skyLevel = helperSkyTransform(l.skyLight);
    let skyFwidth = fwidth(skyLevel);
    let dSkyX = dpdx(skyLevel);
    let dSkyY = dpdy(skyLevel);
    let dPosX = dpdx(l.position);
    let dPosY = dpdy(l.position);
    let faceNormal = normalize(l.normal);
    let faceArea = dot(faceNormal, cross(dPosX, dPosY));
    let areaOk = abs(faceArea) > 0.00000001;
    // Gradient of skyLevel along the surface, in blocks (from the screen-space derivatives).
    // (API v5 negates dpdy for packs; position and sky light are both affected, so this is unchanged.)
    let skyGradient = select(vec3f(0.0),
        (dSkyX * cross(dPosY, faceNormal) + dSkyY * cross(faceNormal, dPosX)) / select(1.0, faceArea, areaOk),
        areaOk);

    if (bloxdLit()) {
        let d = bloxdSunDirection();
        let sunLen = length(d);
        var sunDir = vec3f(0.0, 1.0, 0.0);
        if (sunLen > 0.001) {
            sunDir = d / sunLen;
        }
        // Must be read AFTER sunDir is normalized, otherwise it is never negative
        let sunY = sunDir.y;

        let sky = clamp(l.skyLight, 0.0, 1.0);
        let underground = 1.0 - sky;
        let blockRaw = max(l.blockLight.r, max(l.blockLight.g, l.blockLight.b));
        // Held lights (torch in hand etc.) arrive in l.heldLight, separate from blockLight,
        // so they must be counted too or they get darkened like unlit areas.
        let heldRaw = max(l.heldLight.r, max(l.heldLight.g, l.heldLight.b));
        let localRaw = max(blockRaw, heldRaw);
        // sqrt lifts weak/medium torch light so lamp-lit spots read clearly
        let blockInt = sqrt(helperClamp(localRaw));
        let keep = 0.12 + 0.88 * blockInt;         // lift lamp-lit spots
        out.colour *= mix(keep, 1.0, sky * sky);     // nonlinear (squared) darkening

        // --- Shadow skew prototype: retreat the shadow edge on the sun-facing side ---
        // Sky light falls towards the shadow core, so -gradient points at the core. If the core lies away
        // from the sun, this fragment is on the sun side of the shadow, where a real sun shadow would be thinner.
        let skyGradH = skyGradient.xz;
        let skyGradMag = length(skyGradH);
        let coreDir = -skyGradH / max(skyGradMag, 0.00001);
        let sunH = sunDir.xz;
        let sunHLen = length(sunH);
        // Smooth over the whole -1..1 range (not a hard cut at 0): the gradient is constant per triangle, so a
        // steep curve makes the two triangles of a block face jump to different shadow shifts.
        let sunSide = smoothstep(-1.0, 1.0, -dot(coreDir, sunH / max(sunHLen, 0.00001)));
        let gradReliable = smoothstep(0.15, 0.6, skyGradMag);
        // Shadow length per unit of occluder height: cot(sun elevation), faded out for a night/overhead sun.
        let shadowLength = clamp(sunHLen / max(sunY, 0.15), 0.0, 3.0) * smoothstep(0.02, 0.15, sunY);
        let shadowShrink = min(SHADOW_SKEW_BLOCKS * shadowLength * sunSide * gradReliable, 8.0);
        let shadowVal = calculateContactShadow(skyLevel, skyFwidth, shadowShrink);
        let invShadow = 1.0 - shadowVal;
        let sunPitch = smoothstep(0.01, 0.20, sunLen);

        // Day: fade shadow in/out with sun elevation. Night: keep contact shadow
        // on, since moonlit/ambient light is occluded under overhangs too.
        let daySunAngle = mix(1.0, smoothstep(-0.15, 0.35, sunY), sunPitch);
        let nightAngle = 1.0 - smoothstep(-0.30, -0.05, sunY);
        let sunAngleFactor = max(daySunAngle, nightAngle * 0.9);

        // Weaker contact shadow on vertical faces; top and bottom faces are unchanged.
        let contactNormal = normalize(l.normal);
        let sideFace = 1.0 - abs(contactNormal.y);
        let sideScale = mix(1.0, SIDE_SHADOW_SCALE, smoothstep(0.3, 0.9, sideFace));

        // Shadow = sky occlusion (darkens all light; weaker by day) + sun shadow (darkens only the sun's light,
        // applied in the day branch below). At night only the first part matters.
        let shadowDay = smoothstep(-0.10, 0.06, sunY);
        let localMask = 1.0 - helperClamp(blockInt) * 0.9;
        let ambientPart = mix(1.0, SHADOW_AMBIENT_PART, shadowDay);
        let maskedContactShadow = SHADOW_STRENGTH * invShadow * sunAngleFactor * sideScale * ambientPart * localMask;
        // Bluish: shadows are lit by the blue sky, not just darker
        out.colour *= vec3f(1.0) - maskedContactShadow * (vec3f(1.0) - SHADOW_TINT);

        // Sun shadow amount (used in the day branch), faded at dusk so low-sun shadows are softer
        let duskFade = mix(1.0 - SHADOW_DUSK_FADE, 1.0, smoothstep(0.0, 0.35, sunY));
        let sunShadowAmt = SHADOW_SUN_PART * invShadow * duskFade * localMask;

        let n = normalize(l.normal);
        let viewDir = normalize(bloxdEyePosition() - l.position);
        let skyVal = clamp(l.skyLight, 0.0, 1.0);

        // Day lighting fades in just before sunrise and is fully on a few degrees up,
        // so dawn/dusk are not drawn with the grey-blue moon path.
        let dayFactor = smoothstep(-0.10, 0.06, sunY);
        let t = (bloxdSeconds() % TIME_WRAP) * WIND_SPEED;
        let place = l.position + vec3f(bloxdRenderOffset() % vec3i(4096));

        let unlitColor = out.colour;

        // --- DAY LIGHTING COMPONENT ---
        var dayColor = out.colour;
        if (sunLen > 0.5 && sunY > -0.10) {
            let lambert = max(dot(n, sunDir), 0.0);
            // Wrapped diffuse for the shading (the highlights below keep the plain lambert): the light wraps
            // past 90 degrees from the sun, so more faces are lit and the faces away from it are less dark.
            let wrapped = clamp((dot(n, sunDir) + DAY_LIGHT_WRAP) / (1.0 + DAY_LIGHT_WRAP), 0.0, 1.0);
            let shadowFactor = smoothstep(0.0, 0.85, wrapped);
            let deepenedShadow = pow(shadowFactor, 1.2);

            let horizonTint = vec3f(0.85, 0.88, 0.95);
            let normalSunTint = vec3f(0.5, 0.5, 0.5);
            // Warm tint at similar brightness to the normal tint (was a neutral 1.25, which overexposed dawn/dusk)
            let sunsetSunTint = vec3f(0.75, 0.42, 0.30);
            let sunsetFactor = 1.0 - smoothstep(0.0, 0.35, abs(sunY));
            let sunLightTint = mix(normalSunTint, sunsetSunTint, sunsetFactor);

            let directionalLight = mix(horizonTint, sunLightTint, deepenedShadow);

            let ambientLightFactor = mix(DAY_AWAY_AMBIENT, 0.8, max(n.y, 0.05)) + wrapped * 0.45;
            let verticalAlign = smoothstep(0.20, 0.95, n.y);
            let upwardBoost = 1.0 + verticalAlign * 0.08;
            let sunGlow = pow(shadowFactor, 4.0) * 0.03;

            dayColor *= directionalLight * ambientLightFactor * upwardBoost;
            dayColor += vec3f(sunGlow) * skyVal;

            let h = normalize(viewDir + sunDir);
            let ndh = max(dot(n, h), 0.0);
            let spec = pow(ndh, 0.01) * 0.4 * lambert * (0.3 + 0.7 * skyVal);
            dayColor += spec * vec3f(1.15, 1.15, 1.15);

            let glintAmount = sunGlintAmount(l.flags, l.textureId);
            let tinyCore = pow(ndh, 800.0) * 2.0 * lambert * skyVal * glintAmount;
            dayColor += tinyCore * vec3f(1.3, 1.3, 1.3);

            // Medium highlight, shiny blocks only: as wide as the broad glow above, a bit brighter
            let shinyBroad = pow(ndh, 0.01) * SHINY_SUN_STRENGTH * lambert * (0.3 + 0.7 * skyVal) * glintAmount;
            dayColor += shinyBroad * vec3f(1.2, 1.2, 1.2);

            // Sun shadow: removes only the sun's light, in proportion to how much sun this face gets
            // (shadowFactor), so faces turned away from the sun aren't darkened again. Highlights go too.
            dayColor *= vec3f(1.0) - sunShadowAmt * shadowFactor * (vec3f(1.0) - SHADOW_TINT);

            // Red/orange cast over everything the sky reaches while the sun is near the horizon
            dayColor *= mix(vec3f(1.0), SUNSET_TINT, sunsetFactor * SUNSET_STRENGTH);
        }

        // --- NIGHT LIGHTING COMPONENT ---
        var nightColor = out.colour;
        let moonLambert = max(dot(n, -sunDir), 0.0);
        let moonTint = vec3f(0.85, 0.9, 1.05);
        let moonLight = moonTint * (0.45 + moonLambert * 0.65);
        nightColor *= mix(vec3f(1.0), moonLight, skyVal * 0.95);

        // Sun/moon lighting only applies where the sky actually reaches, so
        // interiors and torch-lit areas are not dimmed by it.
        // Reaches full strength by skyLight 0.4 so open-air shading keeps its contrast.
        let skyMask = smoothstep(0.0, 0.4, skyVal);
        let litResult = mix(unlitColor, mix(nightColor, dayColor, dayFactor), skyMask);
        // Local lights (held + block) are not dimmed by moon/sun lighting at night.
        let dayAmount = dayFactor * skyMask;
        let protectLocal = smoothstep(0.03, 0.35, localRaw) * (1.0 - dayAmount);
        out.colour = mix(litResult, unlitColor, protectLocal * 0.9);

        // --- WIND SHIMMER & GUSTS ---
        var rustle = 1.0;
        // Leaves and wool (all colours) shimmer the same way
        if (LEAF_SHIMMER > 0.0 && (isLeaf(l.flags) || isWool(l.textureId))) {
            let gust = mistNoise(place.xz * 0.7 + place.y * 0.4 + vec2f(t * 0.9, t * 0.55), 9u);
            rustle = 1.0 + (gust - 0.5) * 2.0 * LEAF_SHIMMER * WIND_STRENGTH;
        }
        if (GRASS_GUSTS > 0.0 && l.normal.y > 0.5 && isGrassBlock(l.flags)) {
            rustle *= 1.0 + grassGust(place, t) * GRASS_GUSTS * mix(0.4, 1.0, dayFactor);
        }
        out.colour *= rustle;

        out.colour = finishLook(out.colour, l);
    } else {
        // Lighting off: bright noon look so the world isn't flat; shiny blocks get a slanted highlight
        let glintAmountUnlit = sunGlintAmount(l.flags, l.textureId);
        out.colour = finishLook(
            noonShade(out.colour, l.normal, bloxdEyePosition() - l.position, glintAmountUnlit), l);
    }
    return out;
}

fn bloxdTerrainLight(surface: BloxdSurface, light: BloxdLightIn) -> BloxdLight {
    return shadeLight(surface, light);
}

// Water used to fall back to the terrain hooks; in v5 it needs its own light hook to keep this look.
// (Your liquid surface hook lives in liquid.wgsl.)
fn bloxdLiquidLight(surface: BloxdSurface, light: BloxdLightIn) -> BloxdLight {
    return shadeLight(surface, light);
}

// Block models (slabs, stairs, flat plants) get the same look. Items in hands/on the ground/in flight
// and lifeforms (players, mobs, armour) keep the engine default.
fn bloxdModelLight(surface: BloxdSurface, light: BloxdLightIn) -> BloxdLight {
    // Both are computed for every fragment so the derivatives inside shadeLight stay in uniform control flow.
    let shaded = shadeLight(surface, light);
    var out = bloxdDefaultLight(surface, light);
    let f = light.flags;
    let isEntity = f.lifeform || f.held || f.dropped || f.thrown;
    // Start from the default and change its colour: packs can't construct BloxdLight directly.
    out.colour = select(shaded.colour, out.colour, isEntity);
    return out;
}
