fn bloxdLiquidSurface(s: BloxdSurfaceIn) -> BloxdSurface {
    var out = bloxdDefaultSurface(s);
    let worldX = s.position.x + f32(bloxdOriginOffset().x);
    let worldZ = s.position.z + f32(bloxdOriginOffset().z);
    let ripple = sin(bloxdTime() * 2.1 + worldX * 1.3 + worldZ * 0.9);
    
    // Natural lake and river blue-green tint with slightly enhanced vibrancy
    let lakeColour = vec3f(0.2, 1, 0.80);
    out.colour = clamp(out.colour * lakeColour * (1.0 + ripple * 0.08), vec3f(0.0), vec3f(1.0));
    
    #ifdef BLOXD_ALPHA
    out.alpha = 0.6;
    #endif
    return out;
}