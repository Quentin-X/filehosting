const SHADOW_STRENGTH: f32 = 0.75;

fn helperClamp(x: f32) -> f32 {
    return clamp(x, 0.0, 1.0);
}

fn helperSkyTransform(e: f32) -> f32 {
    let c = 1.0 - pow(max(1.0 - helperClamp(e), 0.0), 1.0 / 3.0);
    return 45.0 * c / max(1.0 + 2.0 * c, 1.0);
}

fn calculateContactShadow(l: BloxdLightIn) -> f32 {
#ifdef BLOXD_LIGHTING
    let v = helperSkyTransform(l.skyLight);
    let e = min(fwidth(v) * 0.55, 0.40);
    return smoothstep(14.12 - e, 14.93 + e, v);
#else
    return 1.0;
#endif
}

fn pack_saturation(c: vec3f, amount: f32) -> vec3f {
    let luma = dot(c, vec3f(0.299, 0.587, 0.114));
    return clamp(mix(vec3f(luma), c, 1.0 + amount), vec3f(0.0), vec3f(1.0));
}

fn bloxdTerrainSurface(s: BloxdSurfaceIn) -> BloxdSurface {
    var surfaceOut = bloxdDefaultSurface(s);

    let baseColor = s.colour;
    let luminance = dot(baseColor, vec3f(0.2126, 0.7152, 0.0722));
    let adjustedColor = mix(vec3f(luminance), baseColor, 1.0);
    let contrastColor = (adjustedColor - vec3f(0.40)) * 1.15 + vec3f(0.43);

    let finalColor = max(contrastColor, vec3f(0.0)) * 1.12;
    surfaceOut.colour = clamp(finalColor, vec3f(0.0), vec3f(1.0));

#ifdef BLOXD_ALPHA
    surfaceOut.alpha = s.alpha;
#endif

    return surfaceOut;
}

fn bloxdTerrainLight(s: BloxdSurface, l: BloxdLightIn) -> BloxdLight {
    var out = bloxdDefaultLight(s, l);
    
#ifdef BLOXD_LIGHTING
    let d = bloxdSunDirection();
    let sunLen = length(d);
    var sunDir = vec3f(0.0, 1.0, 0.0);
    var sunY = 1.0;
    if (sunLen > 0.001) {
        sunDir = d / sunLen;
        sunY = sunDir.y;
    }

    let sky = clamp(l.skyLight, 0.0, 1.0);
    let underground = 1.0 - sky;
    let blockInt = max(l.blockLight.r, max(l.blockLight.g, l.blockLight.b));
    let keep = 0.3 + 0.7 * blockInt;          
    out.colour *= mix(keep, 1.0, sky * sky);      

    let shadowVal = calculateContactShadow(l);
    let invShadow = 1.0 - shadowVal;
    let sunPitch = smoothstep(0.01, 0.20, sunLen);

    let sunAngleFactor = mix(1.0, smoothstep(-0.15, 0.35, sunY), sunPitch);
    let contactShadowFactor = SHADOW_STRENGTH * invShadow * sunAngleFactor;
    let maskedContactShadow = contactShadowFactor * (1.0 - helperClamp(blockInt) * 0.65);
    
    out.colour = out.colour * (1.0 - maskedContactShadow * (1.0 - 0.30));

    let n = normalize(l.normal);
    let viewDir = normalize(bloxdEyePosition() - l.position);
    let skyVal = clamp(l.skyLight, 0.0, 1.0);

    // Smooth day/night transition factor based on sun height
    let dayFactor = smoothstep(-0.15, 0.15, sunY);

    // --- DAY LIGHTING COMPONENT ---
    var dayColor = out.colour;
    if (sunLen > 0.5) {
        let lambert = max(dot(n, sunDir), 0.0);
        
        let shadowFactor = smoothstep(0.0, 0.85, lambert);
        let deepenedShadow = pow(shadowFactor, 1.2);

        let horizonTint = vec3f(0.85, 0.88, 0.95);
        let normalSunTint = vec3f(0.5, 0.5, 0.5);
        let sunsetSunTint = vec3f(1.25, 1.25, 1.25); 
        
        let sunsetFactor = 1.0 - smoothstep(0.0, 0.35, abs(sunY));
        let sunLightTint = mix(normalSunTint, sunsetSunTint, sunsetFactor);

        let directionalLight = mix(horizonTint, sunLightTint, deepenedShadow);

        let ambientLightFactor = 0.75 + lambert * 0.5;
        let verticalAlign = smoothstep(0.20, 0.95, n.y);
        let upwardBoost = 1.0 + verticalAlign * 0.08;
        let sunGlow = pow(shadowFactor, 4.0) * 0.03;

        dayColor *= directionalLight * ambientLightFactor * upwardBoost;
        dayColor += vec3f(sunGlow) * skyVal;

        let h = normalize(viewDir + sunDir);
        let ndh = max(dot(n, h), 0.0);
        let spec = pow(ndh, 0.01) * 0.4 * lambert * (0.3 + 0.7 * skyVal);
        dayColor += spec * vec3f(1.15, 1.15, 1.15);

        let tinyCore = pow(ndh, 800.0) * 2.0 * lambert * skyVal;
        dayColor += tinyCore * vec3f(1.3, 1.3, 1.3);
    }

    // --- NIGHT LIGHTING COMPONENT ---
    var nightColor = out.colour;
    let moonLambert = max(dot(n, -sunDir), 0.0);
    let moonTint = vec3f(0.85, 0.9, 1.05); 
    let moonLight = moonTint * (0.35 + moonLambert * 0.75); 
    nightColor *= mix(vec3f(1.0), moonLight, skyVal * 0.95);

    // Smoothly blend between night and day based on sun angle
    out.colour = mix(nightColor, dayColor, dayFactor);

    let dist = distance(bloxdEyePosition(), l.position);
    let haze = clamp((dist - 40.0) / 128.0, 0.0, 1.0) * 0.35;
    out.colour = mix(out.colour, l.fogColour, haze);
#else
    out.colour = pack_saturation(out.colour, 0.0);
#endif

    return out;
}